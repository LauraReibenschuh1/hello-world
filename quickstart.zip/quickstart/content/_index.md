---
title: "This is our first website"
featured_image: '/images/gohugo-default-sample-hero-image.jpg'
description: "We just installed the Ananke theme. Now we're adding some content."
---
This is work in progress. The next step is to install another theme and customize it. See you there!
